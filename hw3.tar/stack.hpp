/*
    By: Roderick Shaw
    Class: COP 4530
    Section: 0006
    Project/HW #: 3
    Summary:

*/
#ifndef STACK_HPP
#define STACK_HPP

//All Stack member functions

template <typename T>
Stack<T>::Stack() // zero-argument constructor.
{    deq = std::deque<T>();    }
template <typename T>
Stack<T>::~Stack () // destructor.
{    clear();    }

template <typename T>
Stack<T>::Stack (const Stack<T>& stk) // copy constructor.
{
    deq = stk.deq;
    std::cout << "Copying..." << std::endl;
}
template <typename T>
Stack<T>::Stack(Stack<T> && stk) // move constructor.
{
    std::swap(deq, stk.deq);
    std::cout << "Moving..." << std::endl;
}

template <typename T>
Stack<T>& Stack<T>::operator= (const Stack <T>& stk) // copy assignment operator=.
{
    deq = stk.deq;
    return *this;
}
template <typename T>
Stack<T> & Stack<T>::operator=(Stack<T> && stk) // move assignment operator=
{
    deq = std::move(stk.deq);
    std::cout << "Assigned moving..." << std::endl;
    return *this;
}

template <typename T>
bool Stack<T>::empty() const
// returns true if the Stack contains no elements, and false otherwise.
{    return deq.empty();    }

template <typename T>
void Stack<T>::clear() // delete all elements from the stack.
{    deq.clear();    }

template <typename T>
void Stack<T>::push(const T& x) // adds  x  to the Stack.   copy version.
{    deq.push_back(x);    }
template <typename T>
void Stack<T>::push(T && x) // adds x to the Stack. move version.
{    deq.push_back(std::move(x));    }

template <typename T>
void Stack<T>::pop() // removes and discards the most recently added element of the Stack.
{    deq.pop_back();    }
template <typename T>
T& Stack<T>::top()
// returns a reference to the most recently added element of the Stack
//(as a modifiable L-value).
{    return deq.back();    }

template <typename T>
const T& Stack<T>::top() const
// accessor that returns the most recently added element of the Stack (as a const reference)
{    return deq.back();    }

template <typename T>
int Stack<T>::size() const // returns the number of elements stored in the Stack.
{    return deq.size();    }

template <typename T>
void Stack<T>::print(std::ostream& os, char ofc) const{
    for( auto ditr = deq.begin(); ditr != deq.end(); ditr++)
        os << *ditr << ofc;
}
// print elements of Stack to ostream os. ofc is the separator between elements
// in the stack when they are printed out. Note that print() prints elements in
// the opposite order of the Stack (that is, the oldest element should be printed
// first).

//All non-member functions

//The following non-member functions should also be supported.
template <typename T>
std::ostream& operator<< (std::ostream& os, const Stack<T>& a){
    a.print(os);
    return os;
}
// invokes the print() method to print the Stack<T> a in the specified ostream
template <typename T>
bool operator== (const Stack<T>& stk1, const Stack <T>& stk2){
    Stack<T> col1 = stk1, col2 = stk2;

    if(stk1.size() == stk2.size()){
        while((col1.size() != 0)&&(col2.size() != 0)){
            if(col1.top() != col2.top()) return false;
            col1.pop();
            col2.pop();
        }
        return true;
    }
    return false;
}
// returns true if the two compared Stacks have the same elements, in the same order, and
// false otherwise
template <typename T>
bool operator!= (const Stack<T>& stk1, const Stack <T>& stk2)// opposite of operator==().
{    return !(stk1 == stk2);    }

template <typename T>
bool operator<= (const Stack<T>& a, const Stack <T>& b){
    Stack<T> col1 = a, col2 = b;

    if(a.size() <= b.size()){
        while((col1.size() != 0)&&(col2.size() != 0)){
            if(col1.top() > col2.top()) return false;
            col1.pop();
            col2.pop();
        }
        return true;
    }
    return false;
}
/* returns true if every element in Stack a is smaller than or equal to the corresponding
   element of Stack b, i.e., if repeatedly invoking top() and pop() on both a and b,  we will
   generate a sequence of elements ai from a and bi from b, and for every i,  ai ≤ bi, until
   a is empty. (Note that this also means that a cannot have more elements than b for this
   condition to be true). Return false otherwise.
*/

#endif // STACK_HPP
