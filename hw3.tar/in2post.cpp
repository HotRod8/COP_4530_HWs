/*
    By: Roderick Shaw
    Class: COP 4530
    Section: 0006
    Project/HW #: 3
    Summary: Your program should expect as input from (possibly re-directed) stdin a series
    of space-separated strings. Each line of input is one expression. Each of the
    space-separated strings within the line is a token (an operand, an operator, or a
    parethesis). The user should type "exit" on a single line to end processing the inputs.

    Regarding tokens: If you read a1 (no space) this is the name of the variable a1 and not
    "a" followed by "1".  Similarly, if you read "bb 12", this is a variable "bb" followed by
    the number "12" and not "b" ,"b", "12" or "bb", "1" ,"2".

    For each expression (i.e. each line of input), the resulting postfix expression should be
    printed to stdout, followed by the evaluation of the expression. If the expression
    contains only numeric operands, evaluate the expression (using the post-fix evaluation
    algorithm described above) and print the results to stdout. If the expression contains
    variable names (i.e. not just numeric operands), then just print out the postfix
    expression in this spot.

*/

#include <iostream>
#include <cctype>
#include <cstdlib>
#include "stack.h"

using namespace std;
using namespace cop4530;

bool ExcessOpError(const Stack<string>&, const Stack<string>&);
bool OpPrecedence(const string&, const string&);
void ArithOutput(string, Stack<string>);
string& ArithLogic(double&, double&, string, string, Stack<string>);

/*
This is currently my final version of this assignment.
I've finished the error checking, and I almost finished the
summarized output, but I was having a few errors and I decided
to wrap it up. If you could show what I messed up when the Arith
functions, that would be very cool! Anyway, have a good day!
*/
int main(){
    Stack<string> stkstr, temp, postfix;
    string infix, vars = "", output = "";

    while(infix != "exit"){
        cout << "This program focuses on converting infix expressions "
             << "to postfix expressions.\n";
        cout << "Enter an infix expression to see its postfix counterpart:" << endl;
        getline(cin, infix);
        if(infix == "exit") continue;

        cout << "You inputted a string ";
        for(auto x : infix){
            if(isspace(x)){
    //            cout << "String stacked ";
                stkstr.push(vars);
                vars = "";
            }
            else{
    //            cout << "You Appended ";
                vars += x;
            }
        }
        cout << "Vars: " << vars;
        stkstr.push(vars);
        vars = "";

        cout << "\nHere's what currently lies in the stack: " << stkstr << endl;
        cout << "\nPrinting from bottom to top: \n";
        while(!stkstr.empty()){
            temp.push(stkstr.top());
            cout << temp.top() << ' ';
            stkstr.pop();
        }

        while(!temp.empty()){
            //Compare every string token to their string operator counterparts.
            //Else, put the string token into output.
            if(temp.top() == "("){
                postfix.push(temp.top());
                temp.pop();
                if(ExcessOpError(temp, postfix) == true) return 0;
            }
            else if((temp.top() == "+")||(temp.top() == "-")
                    ||(temp.top() == "*")||(temp.top() == "/"))
            {
                //If input stack reaches +, -, *, or /, print top of the
                //postfix stack to the output and pop it off.
                while( (!postfix.empty())&&(postfix.top() != "(")
                      &&( OpPrecedence(temp.top(), postfix.top()) ) )
                {
                    cout << "I'm in da loop\n";
                    output += postfix.top();
                    output += " ";
                    postfix.pop();
                }
                //Afterwards, push the new op into postfix.
                postfix.push(temp.top());
                cout << "Postfix: " << postfix.top() << endl;
                temp.pop();
                if(ExcessOpError(temp, postfix) == true) return 0;
            }
            else if(temp.top() == ")"){
                while(postfix.top() != "("){
                    cout << "I'm outputting my loop\n";
                    output += postfix.top();
                    output += " ";
                    postfix.pop();
                    if(postfix.empty()){
                        cout << "( was never found. Exiting the program.\n";
                        return 0;
                    }
                }
                postfix.pop();
                temp.pop();
            }
            else{
                output += temp.top();
                output += " ";
                temp.pop();
            }
            cout << "Output: " << output << endl;
        }
        while(!postfix.empty()){
            cout << "Postfix: " << postfix.top() << endl;
            if((postfix.top() == "(")||(postfix.top() == ")")){
                cout << "There are excess parentheses in the stack."
                     << " Exiting the program.\n";
                return 0;
            }
            output += postfix.top();
            output += " ";
            postfix.pop();
        }

//        ArithOutput(output, stkstr);
        cout << "\nHere's our postfix notated expression: " << output << endl;
        output = "";
    }

}

bool ExcessOpError(const Stack<string>& temp, const Stack<string>& postfix)
{
    if(temp.empty()){
        cout << "A " << postfix.top() << " was the last input element."
             << " Exiting the program.\n";
        return true;
    }
    return false;
}
bool OpPrecedence(const string& stk, const string& postfix)
{
    if((stk == "*")||(stk == "/")){
        if((postfix == "*")||(postfix == "/")) return true;
        else return false;
    }
    else if((stk == "+")||(stk == "-")){
        if((postfix == "*")||(postfix == "/")) return true;
        else if((postfix == "*")||(postfix == "/")) return true;
        else return false;
    }
    else return false;
}
void ArithOutput(string output, Stack<string> stkstr)
{
    string vars = "";
    double num1, num2;

    for(auto x : output){
        if(isspace(x)){
            if((vars == "+")||(vars == "-")||(vars == "*")||(vars == "/")){
                vars = ArithLogic(num1, num2, output, vars, stkstr);
                if(vars == "exit") return;
            }
            stkstr.push(vars);
            vars = "";
        }
        else if(isalpha(x)){
            cout << "\nHere's our postfix notated expression: " << output << endl;
            return;
        }
        else vars += x;
    }
    vars = ArithLogic(num1, num2, output, vars, stkstr);
    if(vars == "exit") return;
    cout << "Vars: " << vars;
    stkstr.push(std::move(vars));
    cout << "\nHere's our postfix result: " << stkstr << endl;
}
string& ArithLogic(double& num1, double& num2, string output,
                  string vars, Stack<string> stkstr)
{
    //addition
    if(vars == "+")
    {
        num1 = (double&) stkstr.top();
        stkstr.pop();
        num2 = (double&) stkstr.top();
        stkstr.pop();

        num2 += num1;
        string& theNum = (string&) num2;
        return theNum;
    }
    //subtraction
    else if(vars == "-")
    {
        num1 = (double&) stkstr.top();
        stkstr.pop();
        num2 = (double&) stkstr.top();
        stkstr.pop();

        num2 -= num1;
        string& theNum = (string&) num2;
        return theNum;
    }
    //multiplication
    else if(vars == "*")
    {
        num1 = (double&) stkstr.top();
        stkstr.pop();
        num2 = (double&) stkstr.top();
        stkstr.pop();

        num2 *= num1;
        string& theNum = (string&) num2;
        return theNum;
    }
    //division
    else
    {
        num1 = (double&) stkstr.top();
        stkstr.pop();
        num2 = (double&) stkstr.top();
        stkstr.pop();

        if(num1 == 0){
            cout << "You cannot divide by 0.\n";
            cout << "\nHere's our postfix notated expression: " << output << endl;
            string Exit = "exit";
            string& myexit = Exit;
            return myexit;
        }
        num2 /= num1;
        string& theNum = (string&) num2;
        return theNum;
    }
}
