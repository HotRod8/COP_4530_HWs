

#include "passserver.h"

// public member functions
    PassServer::PassServer(size_t size) : HashTable{size} {}
    // constructor, create a hash table of the
    // specified size. You just need to pass this size parameter to the constructor
    // of the HashTable. Therefore, the real hash table size could be different from
    // the parameter size (because prime_below() will be called in the constructor of
    // the HashTable).
    PassServer::~PassServer() {} // destructor. You need to decide what you
    // should do based on your design of PassServer (how you develop the adaptor
    // class based on the adaptee HashTable). In essence, we do not want to have
    // memory leak.
    bool PassServer::load(const char *filename)
    // load a password file into the HashTable object.
    // Each line contains a pair of username and encrypted password.
    {
        cout << "Loading...\n";
        if(HashTable::load(filename) == true) return true;
        return false;
    }
    bool PassServer::addUser(std::pair<string,  string> & kv)
    // add a new username and password. The password passed in is in plaintext,
    // it should be encrypted before insertion.
    {
        kv.second = encrypt(kv.second);
        cout << "Password encrypted and stored: " << kv.second << endl;
//        std::pair<string, string> newpair(kv.first, newpass);
//        cout << "Your info has been paired." << endl;
        if(insert(kv) != true) return false;
        return true;
    }
    bool PassServer::addUser(std::pair<string, string> && kv)
    // move version of addUser.
    {
        kv.second = encrypt(kv.second);
        cout << "Password encrypted and moved: " << kv.second << endl;
//        std::pair<string, string> newpair(kv.first, newpass);
//        cout << "Your data has been paired." << endl;
        if(insert(kv) != true) return false;
        return true;
    }
    bool PassServer::removeUser(const string & k)
    // delete an existing user with username k.
    {
        cout << "Calling user from hashtable." << endl;
        if(HashTable::remove(k) == true) return true;
        return false;
    }
    bool PassServer::changePassword(const std::pair<string, string> &p,
                                             const string & newpassword)
    // change an existing user's password. Note that both passwords passed in are in
    // plaintext. They should be encrypted before you interact with the hash table.
    // If the user is not in the hash table, return false. If p.second does not match
    // the current password, return false. Also return false if the new password and
    // the old password are the same (i.e., we cannot update the password).
    {
        cout << "Searching for a match" << endl;
        if(match(p) == true)
        {
            cout << "We got a match!" << endl;
            std::pair<string, string> user(p.first, p.second);
            user.second = encrypt(newpassword);
            insert(std::move(user));
            return true;
        }
        else
        {
            cout << "We found no match." << endl;
            return false;
        }

    }

    bool PassServer::find(const string & user)
    // check if a user exists (if user is in the hash table).
    {
        if(contains(user) == true) return true;
        return false;
    }
    void PassServer::dump() const // show the structure and contents of
    // the HashTable object to the screen. Same format as the dump() function in the
    // HashTable class template.
    {
        cout << "Accessing dump." << endl;
        HashTable::dump();
    }
    size_t PassServer::size() const {    return HashTable::size();    }
    // return the HashTable size(the number of username/password pairs in the table).
    bool PassServer::write_to_file(const char *filename)
    // save the username and password combination into a file. Same format as the
    // write_to_file() function in the HashTable class template.
    {
        if(HashTable::write_to_file(filename) == true) return true;
        else return false;
    }

// private member functions
    string PassServer::encrypt(const string & str) // encrypt
    // the parameter str and return the encrypted string.
    {
        char salt[] = "$1$########", password[50];
        strcpy(password, crypt( str.c_str(), salt ));
        string myAccount(password);
        myAccount = myAccount.substr(12, 22);
        cout << myAccount << endl;
        return myAccount;
    }

