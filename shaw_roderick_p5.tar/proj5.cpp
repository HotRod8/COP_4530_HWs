
#include "passserver.h"
#include <cctype>

using namespace std;

void Menu()
{
  cout << "\n\n";
  cout << "l - Load From File" << endl;
  cout << "a - Add User" << endl;
  cout << "r - Remove User" << endl;
  cout << "c - Change User Password" << endl;
  cout << "f - Find User" << endl;
  cout << "d - Dump HashTable" << endl;
  cout << "s - HashTable Size" << endl;
  cout << "w - Write to Password File" << endl;
  cout << "x - Exit program" << endl;
  cout << "\nEnter choice : ";
}

int main()
{
    size_t capacity;
    char choice;
    string username, password, newpassword;
    char filename[100];

    cout << "Enter preferred hash table capacity: ";
    cin >> capacity;

    PassServer userserver(capacity);

    do{
        Menu();
        cin >> choice;

        cin.ignore(200, '\n');

        if(choice == 'l')
        {
            cout << "Enter password file name to load from: ";
            cin.getline( filename, 100 );

            cout << "Opening " << filename << endl;
            if(userserver.load(filename) == false)
                cout << "Cannot find filename: " << filename << endl;
        }
        else if(choice == 'a')
        {
            cout << "Enter username: ";
            cin >> username;
            cout << "Enter password: ";
            cin >> password;

            pair<string, string> kv(username, password);

            if(userserver.addUser(kv) == false)
                cout << "Failed to add user.\n" << endl;
            else cout << "User Added.\n" << endl;
        }
        else if(choice == 'r')
        {
            cout << "Enter username: ";
            cin >> username;

            if(userserver.removeUser(username) == false)
                cout << "Failed to remove user.\n" << endl;
            else cout << "User removed.\n" << endl;
        }
        else if(choice == 'c')
        {
            cout << "Enter username: ";
            cin >> username;
            cout << "Enter password: ";
            cin >> password;

            pair<string, string> dapair(username, password);

            cout << "Enter new password: ";
            cin >> newpassword;

            cout << "Accessing account..." << endl;
            if(userserver.changePassword(dapair, newpassword) == true)
                cout << username << "'s password has changed.\n\n";
            else cout << "Failed to update password.\n\n";
        }
        else if(choice == 'f')
        {
            cout << "Enter username: ";
            cin >> username;

            if(userserver.find(username) == false)
                cout << "Failed to find user.\n" << endl;
            else cout << "User found.\n" << endl;
        }
        else if(choice == 'd')
        {
            userserver.dump();
        }
        else if(choice == 's')
        {
            cout << "Size of Hashtable: " << userserver.size();
        }
        else if(choice == 'w')
        {
cout << "Testing 1" << endl;
            cout << "Enter password file name to write to: ";
            cin.getline( filename, 100 );
cout << "Testing 2" << endl;
            cout << "Activating " << filename << endl;
            if(userserver.write_to_file(filename) == false)
                cout << "File failed to be written.";
        }
        else if( tolower((int)choice) == 'x' )
            cout << "Thank you for using this program!\n";
        else cout << "Wrong input. Try again" << endl;
    }while( tolower((int)choice) != 'x' );
}
