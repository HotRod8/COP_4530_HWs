
/*
	By: Roderick Shaw
	Class: COP 4530
	Project/HW #: 4
	Summary: This file utilizes a binary expression tree to convert postfix expressions into
	infix expressions.
*/

/*
    struct BinaryNode{
        string element;
        BinaryNode * leftkid;
        BinaryNode * rightkid;
    };
*/

#include <iostream>
#include "BET.h"
using namespace std;

/*public functions*/
    BET::BET()  // default zero-parameter constructor. Builds an empty tree.
    {    root = new BinaryNode();    }
    BET::BET(const string& postfix) : BET()
    {
        if( buildFromPostfix(postfix) == false ){
            cout << "The tree building was unsuccessful.\n";
            while ( !stknode.empty() ){
//                cout << "Emptying " << stknode.top()->element << '\n';
                root = stknode.top();
                makeEmpty(root);
                stknode.pop();
            }
        }
    }
    // one-parameter constructor, where parameter "postfix" is string containing
    // a postfix expression. The tree should be built based on the postfix
    // expression. Tokens in the postfix expression are separated by spaces.
    BET::BET(const BET& tree)  // copy constructor -- makes appropriate deep copy of the tree
    {
        root = clone(tree.root);
    }
    BET::~BET()  // destructor -- cleans up all dynamic space in the tree
    {
        makeEmpty(root);
    }
    bool BET::buildFromPostfix(const string& postfix)
    {
        if(empty() != true) makeEmpty(root);
        string vars = "";
        BinaryNode * lchild = new BinaryNode(),
                   * rchild = new BinaryNode();

        for(auto x : postfix){
            if(isspace(x)){
                if(isOperator(vars))
                {
                    if( stknode.empty() ){
                        cout << "The operator had no usable operands." << endl;
                        return false;
                    }
                    rchild = stknode.top();
                    stknode.pop();
                    if( stknode.empty() ){
                        cout << "The operator had only one operand." << endl;
                        return false;
                    }
                    lchild = stknode.top();
                    stknode.pop();

                    root = new BinaryNode(vars, lchild, rchild);

                    stknode.push(root);
                    vars = "";
//                    cout << "pushed operator " << stknode.top()->element << endl;
                }
                else{
                    if( isParentheses(vars) ) return false;
                    lchild = new BinaryNode(vars);
                    stknode.push(lchild);
                    vars = "";
//                    cout << "pushed operand " << stknode.top()->element << endl;
                }
            }
            else vars += x;
        }
//        cout << "Out of the loop." << endl;
        if( isParentheses(vars) ) return false;
        if(vars != ""){
            if( stknode.empty() ){
                cout << "The operator had no usable operands." << endl;
                return false;
            }
            rchild = stknode.top();
            stknode.pop();
            if( stknode.empty() ){
                cout << "The operator had only one operand." << endl;
                return false;
            }
            lchild = stknode.top();
            stknode.pop();

            root = new BinaryNode(vars, lchild, rchild);

            stknode.push(root);
//            cout << "pushed operator " << stknode.top()->element << endl;
        }

        return true;
    }
    // parameter "postfix" is string containing a postfix expression. The tree should
    // be built based on the postfix expression. Tokens in the postfix expression are
    // separated by spaces. If the tree contains nodes before the function is called,
    // you need to first delete the existing nodes. Return true if the new tree is
    // built successfully. Return false if an error is encountered.
    const BET & BET::operator= (const BET & tree)  // copy operator= -- makes appropriate deep copy
    {
        root = clone(tree.root);
        return *this;
    }
    void BET::printInfixExpression() const // Print out the infix expression. Should do this by
    // making use of the private (recursive) version
    {
        if( empty() )
            cout << "Empty tree" << endl;
        else{
            printInfixExpression(root);
            cout << endl;
        }
    }
    void BET::printPostfixExpression() const // Print the postfix form of the expression. Use
    // the private recursive function to help
    {
        if( empty() )
            cout << "Empty tree" << endl;
        else{
            printPostfixExpression(root);
            cout << endl;
        }
    }
    size_t BET::size() const // Return the number of nodes in the tree
    // (using the private recursive function)
    {    return size(root);    }
    size_t BET::leaf_nodes() const
    // Return the number of leaf nodes in the tree.
    //(Use the private recursive function to help)
    {    return leaf_nodes(root);    }
    bool BET::empty() const // return true if the tree is empty. Return false otherwise.
    {
        if(root == 0) return true;
        else return false;
    }
    bool BET::isParentheses(const string& par) const
    {
        if( (par == "(")||(par == ")") ){
            cout << "Invalid operand." << endl;
            return true;
        }
        return false;
    }
    bool BET::isOperator(const string& op) const
    {
        if( (op == "+")||(op == "-")||(op == "*")||(op == "/") )
            return true;
        else return false;
    }
    int BET::OpPrecedence(const string& op) const{
        if(op == "*") return 4;
        else if(op == "/") return 3;
        else if(op == "+") return 2;
        else return 1;
    }
/*private functions*/
    void BET::printInfixExpression(BinaryNode * n) const
    {
        if( n != nullptr )
        {
            if( isOperator(n->element)&&isOperator(n->leftkid->element)&&
               (OpPrecedence(n->element)>OpPrecedence(n->leftkid->element)) )
                cout << "( ";

            printInfixExpression( n->leftkid );

            if( isOperator(n->element)&&isOperator(n->leftkid->element)&&
               (OpPrecedence(n->element)>OpPrecedence(n->leftkid->element)) )
                cout << ") ";

            cout << n->element << ' ';

            if( isOperator(n->element)&&isOperator(n->rightkid->element)&&
               (OpPrecedence(n->element)>=OpPrecedence(n->rightkid->element)) )
                cout << "( ";

            printInfixExpression( n->rightkid );

            if( isOperator(n->element)&&isOperator(n->rightkid->element)&&
               (OpPrecedence(n->element)>=OpPrecedence(n->rightkid->element)) )
                cout << ") ";
        }

    }  // print to the standard output the corresponding infix expression. Note
    // that you may need to add parentheses depending on the precedence of operators.
    // You should not have unnecessary parentheses.
    void BET::makeEmpty(BinaryNode* &t)  // delete all nodes in the subtree pointed to by t.
    {
        if( t != nullptr )
        {
            makeEmpty( t->leftkid );
            makeEmpty( t->rightkid );
            delete t;
//            cout << "Node Destroyed." << endl;
        }
        t = nullptr;
    }
    typename BET::BinaryNode* BET::clone(BinaryNode *t){
        if( t == nullptr )
            return nullptr;
        else
            return new BinaryNode{ t->element, clone( t->leftkid ), clone( t->rightkid ) };
    }
    // clone all nodes in the subtree pointed to by t. Can be called by functions
    // such as the assignment operator=.
    void BET::printPostfixExpression(BinaryNode *n) const
    // print to the standard output the corresponding postfix expression.
    {
        if( n != nullptr )
        {
            printPostfixExpression( n->leftkid );
            printPostfixExpression( n->rightkid );
            cout << n->element << ' ';
        }
    }
    size_t BET::size(BinaryNode * t) const // return the number of nodes in the subtree pointed to by t.
    {
        //tracks the number of nodes in the whole tree
        int daSize = 1;

        if(t->leftkid != 0)
            daSize += size(t->leftkid);
        if(t->rightkid != 0)
            daSize += size(t->rightkid);

        return daSize;
    }
    size_t BET::leaf_nodes(BinaryNode * t) const // return the number of leaf nodes in the
    // subtree pointed to by t.
    {
        //variable used to track the number of leaf nodes in a tree
        int numleaves = 0;

        if(t->leftkid != 0)
            numleaves += leaf_nodes(t->leftkid);
        if(t->rightkid != 0)
            numleaves += leaf_nodes(t->rightkid);
        if((t->leftkid == 0)&&(t->rightkid == 0))
            numleaves++;

        return numleaves;
    }

