/*
    By: Roderick Shaw
    Class: COP 4530
    Section: 0006
    Project/HW #: 2
    Summary:

*/

#ifndef DL_LIST_HPP
#define DL_LIST_HPP

using std::cout;
using std::endl;

template <typename T>
List<T>::const_iterator::const_iterator() : current{ nullptr } {}
// default zero parameter constructor
template <typename T>
const T & List<T>::const_iterator::operator*() const
// operator*() to return element
{    return retrieve();    }

// increment/decrement operators
template <typename T>
typename List<T>::const_iterator & List<T>::const_iterator::operator++()
{
    current = current->next;
    return *this;
}
template <typename T>
typename List<T>::const_iterator List<T>::const_iterator::operator++(int)
{
    const_iterator old = *this;
    ++(*this);
    return old;
}
template <typename T>
typename List<T>::const_iterator & List<T>::const_iterator::operator--()
{
    current = current->prev;
    return *this;
}
template <typename T>
typename List<T>::const_iterator List<T>::const_iterator::operator--(int)
{
    const_iterator old = *this;
    --(*this);
    return old;
}

// comparison operators
template <typename T>
bool List<T>::const_iterator::operator==(const List<T>::const_iterator &rhs) const
{    return current == rhs.current;    }
template <typename T>
bool List<T>::const_iterator::operator!=(const List<T>::const_iterator &rhs) const
{    return current != rhs.current;    }

//protected:
template <typename T>
T & List<T>::const_iterator::retrieve() const       // retrieve the element refers to
{    return current->data;    }
template <typename T>
List<T>::const_iterator::const_iterator(Node *p) : current{ p } {}    // protected constructor


// nested iterator class
template <typename T>
List<T>::iterator::iterator() {}
template <typename T>
T & List<T>::iterator::operator*()
{    return List<T>::const_iterator::retrieve();    }
template <typename T>
const T & List<T>::iterator::operator*() const
{    return List<T>::const_iterator::operator*();    }

// increment/decrement operators
template <typename T>
typename List<T>::iterator & List<T>::iterator::operator++()
{
    this->current = this->current->next;
    return *this;
}
template <typename T>
typename List<T>::iterator List<T>::iterator::operator++(int)
{
    List<T>::iterator old = *this;
    ++(*this);
    return old;
}
template <typename T>
typename List<T>::iterator & List<T>::iterator::operator--()
{
    this->current = this->current->prev;
    return *this;
}
template <typename T>
typename List<T>::iterator List<T>::iterator::operator--(int)
{
    List<T>::iterator old = *this;
    --(*this);
    return old;
}
//protected iterator
template <typename T>
List<T>::iterator::iterator (Node *p) : List<T>::const_iterator(p) {}

template <typename T>
List<T>::List()                  // default zero parameter constructor
{     init();     }
template <typename T>
List<T>::List(const List &rhs)   // copy constructor
{
    init();
    for( auto& x : rhs ){
        cout << x << '\n';
        push_back(x);
    }
}
template <typename T>
List<T>::List(List && rhs)
 : theSize{ rhs.theSize }, head{ rhs.head }, tail{ rhs.tail }
       // move constructor
{
    rhs.theSize = 0;
    rhs.head = nullptr;
    rhs.tail = nullptr;

//    cout << *this << endl;
}

// num elements with value of val
//
template <typename T>
List<T>::List(int num, const T& val)
{
    init();
    for(int i = 0; i < num; i++)
        insert(begin(), val);
}

// constructs with elements [start, end)
//
template <typename T>
List<T>::List(List<T>::const_iterator start, List<T>::const_iterator end)
{
    init();
    for(auto i = start; i != end; ++i){
//        cout << "My loop\n";
        push_back(*i);
    }

}

// constructs with a copy of each of the elements in the initalizer_list
//
template <typename T>
List<T>::List (std::initializer_list<T> iList)
{
    init();
    for(auto i = iList.begin(); i != iList.end(); i++){
//        cout << "Initializer list\n";
        push_back(*i);
    }
}

template <typename T>
List<T>::~List() // destructor
{
    clear();
    delete head;
    delete tail;
}

// copy assignment operator
template <typename T>
const List<T>& List<T>::operator=(const List &rhs)
{
    List c0py = rhs;
    std::swap( *this, c0py );
    return *this;
}

// move assignment operator
template <typename T>
List<T> & List<T>::operator=(List && rhs)
{
    std::swap( theSize, rhs.theSize );
    std::swap( head, rhs.head );
    std::swap( tail, rhs.tail );

    return *this;
}

// sets list to the elements of the initializer_list
//
template <typename T>
List<T>& List<T>::operator= (std::initializer_list<T> iList)
{
    for(auto i = iList.begin(); i != iList.end(); i++)
        push_back(*i);

    return *this;
}


// member functions
template <typename T>
int List<T>::size() const       // number of elements
{    return theSize;    }
template <typename T>
bool List<T>::empty() const     // check if list is empty
{    return (size() == 0);    }
template <typename T>
void List<T>::clear()           // delete all elements
{
    while( !empty() )
        pop_front();
}
//1
template <typename T>
void List<T>::reverse()         // reverse the order of the elements
{
    typename List<T>::iterator revfront = begin(), revback = --end();
//    typename List<T>::Node* start, finish;

    for(int x = 0; x < theSize/2; x++, revfront++, --revback)
    {
//        cout << "Reversing " << x << " and " << theSize-1-x << '\n';
        std::swap(revfront.retrieve(), revback.retrieve());
    }

}

template <typename T>
T& List<T>::front()             // reference to the first element
{    return *begin();    }
template <typename T>
const T& List<T>::front() const
{    return *begin();    }
template <typename T>
T& List<T>::back()              // reference to the last element
{    return *--end();    }
template <typename T>
const T& List<T>::back() const
{    return *--end();    }

template <typename T>
void List<T>::push_front(const T & val) // insert to the beginning
{    insert( begin( ), val );    }
template <typename T>
void List<T>::push_front(T && val)      // move version of insert
{    insert( begin( ), std::move( val ));    }
template <typename T>
void List<T>::push_back(const T & val)  // insert to the end
{
//    cout << "I'm here." << endl;
    insert( end( ), val);
}
template <typename T>
void List<T>::push_back(T && val)       // move version of insert
{    insert( end( ), std::move( val ));    }
template <typename T>
void List<T>::pop_front()               // delete first element
{    erase( begin() );    }
template <typename T>
void List<T>::pop_back()                // delete last element
{    erase( --end() );    }

//
template <typename T>
void List<T>::remove(const T &val)      // remove all elements with value = val
{
    List<T>::iterator I = begin();
    // auto I = Cities.begin();  // c++11
    while( I != end()) {
        if (val == *I) I = erase(I);
        else I++;
    }

}


//
template <typename T>
template <typename PREDICATE>
void List<T>::remove_if(PREDICATE pred)
// remove all elements for which Predicate pred
// returns true. pred can take in a function object
{
    for (List<T>::iterator i = begin(); i != end(); )
    {
//        cout << *i << endl;
        // if the condition is true, then print the item
        if (pred(*i) == true)
            i = erase(i);
        else i++;
    }

}

// print out all elements. ofc is deliminitor
template <typename T>
void List<T>::print(std::ostream& os, char ofc) const
{
    Node *currPtr = head->next;
    while(currPtr != tail){
        os << currPtr->data << ofc;
        currPtr = currPtr->next;
    }
}

template <typename T>
typename List<T>::iterator List<T>::begin()               // iterator to first element
{    return iterator{ head->next };    }
template <typename T>
typename List<T>::const_iterator List<T>::begin() const
{
//    cout << "Hi!" << endl;
    return const_iterator{ head->next };
}
template <typename T>
typename List<T>::iterator List<T>::end()                 // end marker iterator
{
//    cout << "Hello." << endl;
    return iterator{ tail };
}
template <typename T>
typename List<T>::const_iterator List<T>::end() const
{
//    cout << "Mom." << endl;
    return const_iterator{ tail };
}
template <typename T>
typename List<T>::iterator List<T>::insert(iterator itr, const T& val)  // insert val ahead of itr
{
//    cout << itr.current << endl;
    Node *p = itr.current;
    theSize++;
    return iterator{ p->prev = p->prev->next = new Node{ val, p->prev, p } };
}
template <typename T>
typename List<T>::iterator List<T>::insert(iterator itr, T && val)      // move version of insert
{
    Node *p = itr.current;
    theSize++;
    return iterator{ p->prev = p->prev->next = new Node{ std::move(val), p->prev, p } };
}
template <typename T>
typename List<T>::iterator List<T>::erase(List<T>::iterator itr)                 // erase one element
{
    Node *p = itr.current;
    iterator retVal{ p->next };
    p->prev->next = p->next;
    p->next->prev = p->prev;
    delete p;
    theSize--;

    return retVal;
}
template <typename T>
typename List<T>::iterator List<T>::erase(List<T>::iterator start, List<T>::iterator ending) // erase [start, end]
{
    for( List<T>::iterator itr = start; itr != ending; )
        itr = erase( itr );

    return ending;
}

template <typename T>
void List<T>::init()
{
    theSize = 0;
    head = new Node;
    tail = new Node;
    head->next = tail;
    tail->prev = head;
}

// overloading comparison operators
//
template <typename T>
  bool operator==(const List<T> & lhs, const List<T> &rhs)
  {
    if(lhs.size() == rhs.size()){
        if((lhs.empty())&&(rhs.empty())) return true;

        for(typename List<T>::const_iterator itr1 = lhs.begin(), itr2 = rhs.begin();
            (itr1 != lhs.end())||(itr2 != rhs.end()); itr1++, itr2++)
        {
            if(*itr1 != *itr2) return false;
        }

        return true;
    }

    return false;
  }
template <typename T>
  bool operator!=(const List<T> & lhs, const List<T> &rhs)
  {
    return !(lhs == rhs);
  }

// overloading output operator
template <typename T>
  std::ostream & operator<<(std::ostream &os, const List<T> &l)
  {
    l.print(os);
    return os;
  }


#endif
