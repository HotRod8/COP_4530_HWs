#include <iostream>
#include <string>

#include "tvector.h"

using namespace std;

template <typename T>
void PrintList(const TVector<T>& v, string label)
{
   cout << label << " size is: " << v.GetSize() << "\n"
        << label << " = ";
   v.Print(cout);
   cout << "\n\n";
}

int main()
{
   TVector<int> v1;		// integer list

   for (int i = 0; i < 10; i++)
        v1.InsertBack(i*3);

   PrintList(v1, "v1");

   for (int i = 0; i < 8; i++)
        v1.Insert( v1.GetIterator(), (i+1) * 50 );

   PrintList(v1, "v1");

   for (int i = 0; i < 10; i++)
        v1.RemoveBack();

   PrintList(v1, "v1");

   for (int i = 0; i < 8; i++)
        v1.InsertBack( i * 50 );

   PrintList(v1, "v1");

   v1.Remove(v1.GetIterator());
   PrintList(v1, "v1");

   v1.Remove(v1.GetIterator());
   PrintList(v1, "v1");

   v1.Remove(v1.GetIteratorEnd());
   PrintList(v1, "v1");

   // try an iterator, and some middle inserts/deletes
   cout << "Testing some inserts and removes with an iterator\n\n";

   TVectorIterator<int> itr = v1.GetIterator();
   itr = v1.Insert(itr, 999);
   if(itr.HasPrevious()) itr.Previous();
   if(itr.HasNext()){
        for(int i = 0; i < 4; i++)
            itr.Next();// advance 3 spots
   }
   itr = v1.Insert(itr, 888);
   if(itr.HasNext()) itr.Next();
   if(itr.HasPrevious()){
        for(int i = 0; i < 3; i++)
               itr.Previous();
   }
   if(itr.HasNext()){
        for(int i = 0; i < 4; i++)
            itr.Next();
   }	// advance 2 spots
   itr = v1.Insert(itr, 777);

   PrintList(v1, "v1");

   itr.Next();
   itr.Next();   			// advance two spots
   itr = v1.Remove(itr);		// delete current item
   PrintList(v1, "v1");

   for (int i = 0; i < 5; i++)
      itr.Previous();			// back 5 spots

   itr = v1.Remove(itr);		// delete current item
   PrintList(v1, "v1");

   // building another list

   cout << "Building a new list\n";
   TVector<double> v2;

   for (int i = 0; i < 8; i++)
      v2.InsertBack(i * 0.5 + 1);

   TVectorIterator<double> vtr = v2.GetIteratorEnd();

//   cout << "Printing...\n";
   PrintList(v2, "v2");

//    for (int h = 0; h < v2.GetSize(); h++){
    for (int i = 1; i < 5; i++){
        vtr = v2.Insert(vtr, vtr.GetData() - ((5-i)/10.0));
        vtr.Next();
    }

   PrintList(v2, "v2");

   for(int h = 0; h < 6; h++)
        v2.Remove(v2.GetIterator());

   PrintList(v2, "v2");

   cout << "Testing 2-parameter remove functions:\n\n";

   TVector<double> v10(20.12, 25);
   TVectorIterator<double> itvar1 = v10.GetIterator();
   TVectorIterator<double> itvar2 = v10.GetIterator();

   itvar2.Next();
   itvar2.Next();
   itvar2.Next();
   for(int f = 0; f < 10; f++){
       v10.Remove(itvar1, itvar2);
//       cout << "Inserted and removed...\n";
   }

   cout << "Over erasure blocked.\nLast insert:" << endl;
   v10.Insert(itvar1, 12.345);

   PrintList(v10, "v10");

   // Testing + overload:
   cout << "Testing operator+ overload\n";
   TVector<int> v5 = v1 + TVector<int>(100, 7);

   TVector<double> v6;
   v6 = v2 + TVector<double>(2.569, 5);

   PrintList(v5, "v5");
   PrintList(v6, "v6");

   cout << "Testing forwards and backwards traversals.\n";
   TVectorIterator<int> trav1 = v5.GetIterator();
   TVectorIterator<double> trav2 = v6.GetIteratorEnd();

   cout << "\nNormal Vector 5: ";
   for(int i = 0; i < v5.GetSize(); i++){
        cout << trav1.GetData() << ' ';
        trav1.Next();
   }

   cout << "\nReverse Vector 6: ";
   for(int i = v6.GetSize()-1; i >= 0; i--){
        cout << trav2.GetData() << ' ';
        trav2.Previous();
   }

   cout << "\n\nTesting a call to the 2-param delete\n";
   TVectorIterator<double> itr1 = v6.GetIterator();
   TVectorIterator<double> itr2 = v6.GetIterator();

   itr1.Next();
   itr1.Next();
   cout << "itr1 is attached to: " << itr1.GetData() << '\n';
   for (int i = 0; i < 8; i++)
      itr2.Next();
   cout << "itr2 is attached to: " << itr2.GetData() << '\n';

   cout << "Calling:  v6.Remove(itr1, itr2);\n";
   v6.Remove(itr1, itr2);
   PrintList(v6, "v6");

}
