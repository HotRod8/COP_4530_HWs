/*
    By: Roderick Shaw
    Class: COP 4530
    Section: 0006
    Project/HW #: 1
    Summary: This file utilizes iterators to give the user the ability to use the
    same syntax for every data structure process.

*/
#ifndef TVECTOR_HPP
#define TVECTOR_HPP

using std::cout;
using std::endl;

    // TVector templated class functions

template <typename T>
TVector<T>::TVector()
// create empty vector
{
    size = 0;    capacity = size+SPARECAPACITY;
    array = new T[capacity];
//    cout << size << ' ' << capacity << endl;
}

template <typename T>
TVector<T>::TVector(T val, int num)		// create vector with num copies of val
{
    size = num;    capacity = size + SPARECAPACITY;
    array = new T[capacity];
    for(int i = 0; i < num; i++)
        array[i] = val;
}

template <typename T>
TVector<T>::~TVector()					// destructor
{    Clear();    }
template <typename T>
TVector<T>::TVector(const TVector<T>& v)		// copy constructor
{
    //Assign all parameter member data to caller
    size = v.size;
    capacity = v.capacity;

    array = new T[capacity];

    for(int i = 0; i < capacity; ++i)
        array[i] = v.array[i];
}
template <typename T>
TVector<T>& TVector<T>::operator=(const TVector<T>& v)   // copy assignment operator
{
    if(this != &v){
        delete [] array;
        //Assign all parameter member data to caller
        size = v.size;
        capacity = v.capacity;

        array = new T[capacity];

        for(int i = 0; i < capacity; ++i)
            array[i] = v.array[i];
    }
    return *this;
}

template <typename T>
TVector<T>::TVector(TVector<T> && v)			// move constructor
{
    size = v.size;
    capacity = v.capacity;
    array = v.array;

    v.array = nullptr;
    v.size = v.capacity = 0;
}
template <typename T>
TVector<T>& TVector<T>::operator=(TVector<T> && v)	// move assignment operator
{
    std::swap(capacity, v.capacity);	// swap trackers between calling obj and param
    std::swap(size, v.size);
    std::swap(array, v.array);	// trade pointers between calling obj and param

    return *this;
}

template <typename T>
bool TVector<T>::IsEmpty() const		// checks to see whether container is empty
{    return (size == 0);    }
template <typename T>
void TVector<T>::Clear()			// clear out vector, reset to empty
{
    size = 0;
    delete [] array;
}
template <typename T>
int TVector<T>::GetSize() const			// return the size of the vector
{    return size;    }

template <typename T>
void TVector<T>::InsertBack(const T& d)		// insert data d as last element
{
    if(size == capacity) SetCapacity(2*size+SPARECAPACITY);
    array[size++] = d;
//    cout << array[size-1] << endl;
}
template <typename T>
void TVector<T>::RemoveBack()			// remove last element of vector
{    if(!IsEmpty()) --size;    }

template <typename T>
T& TVector<T>::GetFirst() const			// return first element of vector
{    return array[0];   }
template <typename T>
T& TVector<T>::GetLast() const			// return last element of vector
{    return array[size-1];    }

template <typename T>
TVectorIterator<T> TVector<T>::GetIterator() const  // return iterator to first item
{
    TVectorIterator<T> itr;
    if(!IsEmpty()){
        itr.ptr = array;
        itr.vsize = size;
    }
    itr.index = 0;
    return itr;
}
template <typename T>
TVectorIterator<T> TVector<T>::GetIteratorEnd() const  // return iterator to last item
{
    TVectorIterator<T> itr;
    if(!IsEmpty()){
        itr.ptr = array;
        itr.vsize = size;
    }
    if(size > 0) itr.index = size - 1;
    else itr.index = size;

    return itr;
}

template <typename T>
void TVector<T>::SetCapacity(unsigned int c)
// reset the capacity of the vector to c.  Adjust size if c is smaller.
// Acts like a Grow or Resize function.
{
    unsigned int storage = capacity;

    if(c >= 0){
        if((capacity > c)&&(size >=c))
            capacity = size = c;
        else if ((capacity > c)&&(size < c))
            capacity = c;
        else if (capacity < c) capacity = c;
    }
    else if(c < 0) capacity = size = 0;

    T* temp = new T[c];

    for(unsigned int i = 0; i < storage; i++)
        temp[i] = array[i];

    delete [] array;
    array = temp;
}

// insert data element d just before item at pos position
//  return iterator to the new data item
template <typename T>
TVectorIterator<T> TVector<T>::Insert(TVectorIterator<T> pos, const T& d)
//Check if iterator is empty or not. Also check if the pos index is
//0 or vsize-1. Code for each scenario accordingly.
{
    if(size == capacity){
        SetCapacity(2*size+SPARECAPACITY);
        pos.ptr = array;
//        cout << "Increased\n";
    }
    pos.vsize = ++size;

//    cout << d << endl;
    if(IsEmpty()) pos.ptr[pos.index] = d;
    //Set d to the element right before the back of the vector iterator.
    //Shift each element up from front to back to not lose their data, then place d in.
    else if((pos.index <= pos.vsize-2)&&(pos.index >= 0)){
//        cout << pos.index << '\n';
        for(unsigned int i = size-1; i > pos.index; i--){
            pos.ptr[i] = array[i-1];
//            cout << i << " Running\n";
        }
        pos.ptr[pos.index] = d;
//        cout << "Inserted " << d << endl;
    }
    //Last case is accounting for valid iterators
    else pos.ptr[pos.index] = d;

    return pos;
}

// remove data item at position pos. Return iterator to the item
//  that comes after the one being deleted
template <typename T>
TVectorIterator<T> TVector<T>::Remove(TVectorIterator<T> pos)
{
    if((pos.index <= pos.vsize-2)&&(pos.index >= 0)){
//        cout << pos.index << '\n';
        for(unsigned int i = pos.index; i < size; i++){
            pos.ptr[i] = array[i+1];
//            cout << i << " Running\n";
        }
    }
    pos.vsize = --size;
    return pos;
}

// remove data item in range [pos1, pos2)
//  i.e. remove all items from pos1 up through but not including pos2
//  return iterator to the item that comes after the deleted items
template <typename T>
TVectorIterator<T> TVector<T>::Remove(TVectorIterator<T> pos1, TVectorIterator<T> pos2)
{
    TVectorIterator<T> tvi, temp = GetIterator();
    if(pos1.index >= pos2.index) return pos1;
    else if(size == 0) return tvi;
    else{
        //Cut out the range by inserting the pos2.index at pos1.index.
        //Repeat this process for the whole vector.
        for(unsigned int i = pos1.index, j = pos2.index; i < size; i++, j++){
            if(pos2.index >= size) return temp;
//            cout << temp.ptr[i] << endl;
            temp.ptr[i] = temp.ptr[j];
        }
        size -= (pos2.index-pos1.index);

        return temp;
    }
}

// print vector contents in order, separated by given delimiter
template <typename T>
void TVector<T>::Print(std::ostream& os, char delim) const
{
    for(unsigned int i = 0; i < size; i++)
        os << array[i] << delim;
}

    //Standalone function w/ TVector return type.
template <typename T>
TVector<T> operator+(const TVector<T>& t1, const TVector<T>& t2)
{
    TVector<T> temp;
    TVectorIterator<T> itr1 = t1.GetIterator(), itr2 = t2.GetIterator();
    int tmax = t1.GetSize()+t2.GetSize();
    //temp.capacity will always be 10 at first.
    //A cap increase is required to store the full combined size.
    temp.SetCapacity(2*tmax);
    for(int i = 0; i < t1.GetSize(); i++){
        temp.InsertBack(itr1.GetData());
        itr1.Next();
    }

    for(int i = 0; i < t2.GetSize(); i++){
        temp.InsertBack(itr2.GetData());
        itr2.Next();
    }

    return temp;
}


// TVectorIterator templated class functions

template <typename T>
TVectorIterator<T>::TVectorIterator()			// default constructor
{
    ptr = 0;
    vsize = 0;
}
template <typename T>
bool TVectorIterator<T>::HasNext() const		// next item available?
{    return (index+1 < vsize);    }
template <typename T>
bool TVectorIterator<T>::HasPrevious() const		// previous item available?
{    return (index-1 <= 0);     }
template <typename T>
TVectorIterator<T> TVectorIterator<T>::Next()		// advance to next item
{
    if(ptr != 0){
        if(index+1 < vsize){
            index++;
//            ptr++;
//            cout << index << endl;
        }
    }
    return *this;
}
template <typename T>
TVectorIterator<T> TVectorIterator<T>::Previous()	// move to previous item
{
    if(ptr != 0){
        if(index-1 >= 0){
            index--;
//            ptr--;
//            cout << index << endl;
        }
    }
    return *this;
}
template <typename T>
T& TVectorIterator<T>::GetData() const			// return data element of current node
{
    TVector<T>* vtr;
    if(ptr == 0) {  return vtr->dummy;  }
    return ptr[index];
}


#endif
